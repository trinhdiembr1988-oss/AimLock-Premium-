package com.btheadlock.ui;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

public class MainActivity extends Activity {
    private static final String KEY = "OB55XINCHAO-7777";
    private final Handler handler = new Handler();
    private LinearLayout root, featureBox;
    private TextView toastText;

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(String color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.parseColor(color));
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView text(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(Color.WHITE);
        return t;
    }

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        showKeyScreen();
    }

    private void base() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(14));
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);
    }

    private ImageView logo(int sizeDp) {
        ImageView image = new ImageView(this);
        image.setImageResource(com.btheadlock.ui.R.drawable.aimlock_logo);
        image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        return image;
    }

    private void showKeyScreen() {
        base();

        Space top = new Space(this);
        root.addView(top, new LinearLayout.LayoutParams(1, 0, 1));

        ImageView logo = logo(180);
        LinearLayout.LayoutParams lpLogo = new LinearLayout.LayoutParams(-1, dp(190));
        root.addView(logo, lpLogo);

        TextView sub = text("V2 PREMIUM", 12);
        sub.setGravity(Gravity.CENTER);
        sub.setTextColor(Color.LTGRAY);
        root.addView(sub, new LinearLayout.LayoutParams(-1, dp(25)));

        EditText key = new EditText(this);
        key.setHint("Nhập key");
        key.setHintTextColor(Color.GRAY);
        key.setTextColor(Color.WHITE);
        key.setSingleLine(true);
        key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        key.setGravity(Gravity.CENTER);
        key.setTextSize(17);
        key.setPadding(dp(16), 0, dp(16), 0);
        key.setBackground(rounded("#171717", 16));
        LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(-1, dp(58));
        kp.setMargins(0, dp(18), 0, dp(12));
        root.addView(key, kp);

        Button enter = new Button(this);
        enter.setText("VÀO MENU");
        enter.setTextColor(Color.WHITE);
        enter.setTextSize(15);
        enter.setAllCaps(false);
        enter.setBackground(rounded("#F21B1B", 16));
        root.addView(enter, new LinearLayout.LayoutParams(-1, dp(56)));

        TextView error = text("", 13);
        error.setGravity(Gravity.CENTER);
        root.addView(error, new LinearLayout.LayoutParams(-1, dp(40)));

        Space bottom = new Space(this);
        root.addView(bottom, new LinearLayout.LayoutParams(1, 0, 1));

        enter.setOnClickListener(v -> {
            if (KEY.equals(key.getText().toString().trim())) {
                showMenu();
            } else {
                error.setText("Sai key");
                error.setTextColor(Color.RED);
            }
        });
    }

    private void showMenu() {
        base();

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView back = text("‹ Back", 18);
        back.setGravity(Gravity.CENTER_VERTICAL);
        back.setOnClickListener(v -> showKeyScreen());
        top.addView(back, new LinearLayout.LayoutParams(dp(80), dp(54)));

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setGravity(Gravity.CENTER);

        TextView title = text("AIMLOCK", 25);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        title.setTextColor(Color.WHITE);
        titleBox.addView(title, new LinearLayout.LayoutParams(-1, dp(30)));

        TextView premium = text("V2 PREMIUM", 9);
        premium.setGravity(Gravity.CENTER);
        premium.setTextColor(Color.LTGRAY);
        titleBox.addView(premium, new LinearLayout.LayoutParams(-1, dp(18)));

        top.addView(titleBox, new LinearLayout.LayoutParams(0, dp(54), 1));

        TextView menu = text("☰", 30);
        menu.setGravity(Gravity.CENTER);
        top.addView(menu, new LinearLayout.LayoutParams(dp(55), dp(54)));
        root.addView(top, new LinearLayout.LayoutParams(-1, dp(58)));

        ImageView logo = logo(150);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(-1, dp(145));
        logoParams.setMargins(0, dp(2), 0, dp(4));
        root.addView(logo, logoParams);

        featureBox = new LinearLayout(this);
        featureBox.setOrientation(LinearLayout.VERTICAL);
        featureBox.setPadding(dp(14), dp(10), dp(10), dp(10));
        featureBox.setBackground(rounded("#171717", 22));
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(330));
        fp.setMargins(0, dp(8), 0, 0);
        root.addView(featureBox, fp);

        addFeature("🎯", "REG FILES", "REG FILES");
        addFeature("🚀", "BOOST RAM", "BOOST RAM");
        addFeature("💀", "HEADLOCK", "HEADLOCK");
        addFeature("⚙️", "FIX RUNG", "FIX RUNG");
        addFeature("📳", "RUNG TÂM", "RUNG TÂM");
        addFeature("♾️", "VÀO GAME", "VÀO GAME");

        toastText = text("", 15);
        toastText.setGravity(Gravity.CENTER);
        toastText.setBackground(rounded("#239BDF", 18));
        toastText.setVisibility(View.GONE);
        addContentView(toastText, new ViewGroup.LayoutParams(dp(290), dp(58)));
    }

    private void addFeature(String icon, String title, String action) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), 0, dp(2), 0);

        TextView ic = text(icon, 21);
        ic.setGravity(Gravity.CENTER);
        row.addView(ic, new LinearLayout.LayoutParams(dp(48), -1));

        TextView name = text(title, 16);
        row.addView(name, new LinearLayout.LayoutParams(0, -1, 1));

        Switch sw = new Switch(this);
        sw.setScaleX(1.05f);
        sw.setScaleY(1.05f);
        sw.setOnCheckedChangeListener((button, checked) -> {
            showToast((checked ? "Đã bật " : "Đã tắt ") + action);
            if (checked && "BOOST RAM".equals(action)) showBoostSquare();
        });
        row.addView(sw, new LinearLayout.LayoutParams(dp(62), -2));

        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(51));
        rp.setMargins(0, 0, 0, dp(3));
        featureBox.addView(row, rp);
    }

    private void showToast(String msg) {
        toastText.setText(msg);
        toastText.setVisibility(View.VISIBLE);
        toastText.post(() -> {
            toastText.setX((getResources().getDisplayMetrics().widthPixels - toastText.getWidth()) / 2f);
            toastText.setY(getResources().getDisplayMetrics().heightPixels - dp(165));
        });
        handler.removeCallbacksAndMessages(toastText);
        handler.postDelayed(() -> toastText.setVisibility(View.GONE), 1800);
    }

    private void showBoostSquare() {
        TextView sq = text("⚡", 17);
        sq.setGravity(Gravity.CENTER);
        sq.setTextColor(Color.BLACK);
        sq.setBackground(rounded("#00E676", 9));
        addContentView(sq, new ViewGroup.LayoutParams(dp(58), dp(58)));
        sq.setX(getResources().getDisplayMetrics().widthPixels - dp(78));
        sq.setY(dp(85));
        handler.postDelayed(() -> {
            ViewGroup p = (ViewGroup)sq.getParent();
            if (p != null) p.removeView(sq);
        }, 3000);
    }
}
