# HeadLock V2 Premium

Android UI demo with a centered key-only login screen.

- Key is password-masked and centered: `OB55XINCHAO-7777`
- After a correct key, the red/black HeadLock V2 Premium menu opens.
- Switches show on/off status and Boost RAM displays a temporary green ⚡ square.
- The UI is a local demo and does not modify, inject into, or bypass Free Fire or its anti-cheat.

## GitHub build
Upload the contents of this project to the repository root, then open **Actions → Build HeadLock V2 Premium → Run workflow**. The APK appears under **Artifacts → HeadLock-V2-Premium-APK** after a successful run.
